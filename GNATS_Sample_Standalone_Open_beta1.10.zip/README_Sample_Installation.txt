Generalized National Airspace Trajectory-Prediction System(GNATS)

Standalone Sample Files

Installation
Please copy and paste the sample directory into GNATS_Standalone folder.
